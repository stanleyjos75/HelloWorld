package com.attacomsian.jpa;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.attacomsian.jpa.one2many.domains.Book;
import com.attacomsian.jpa.one2many.domains.Page;
import com.attacomsian.jpa.one2many.repositories.BookRepository;
import com.attacomsian.jpa.one2many.repositories.PageRepository;



@SpringBootApplication
public class AwsSpringJpaSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsSpringJpaSampleApplication.class, args);
	}


	   @Bean
	    public CommandLineRunner mappingDemo(BookRepository bookRepository,
	                                         PageRepository pageRepository) {
	        return args -> {

	            // create a new book
	            Book book = new Book("Java 101", "John Doe", "123456");

	            // save the book
	            bookRepository.save(book);

	            // create and save new pages
	            pageRepository.save(new Page(1, "Introduction contents", "Introduction", book));
	            pageRepository.save(new Page(65, "Java 8 contents", "Java 8", book));
	            pageRepository.save(new Page(95, "Concurrency contents", "Concurrency", book));
	        };
	    }
	
//	@Bean
//    public CommandLineRunner mappingDemo(UserRepository userRepository,
//            							AddressRepository addressRepository) {
//		
//
//		return args -> {
//		// create a user instance
//        User user = new User("John Doe", "john.doe@example.com", "1234abcd");
//
//        // create an address instance
//        Address address = new Address("Lake View 321", "Berlin", "Berlin",
//                "95781", "DE");
//
//        // set child reference
//        address.setUser(user);
//
//        // set parent reference
//        user.setAddress(address);
//
//        // save the parent
//        // which will save the child (address) as well
//        userRepository.save(user);
//        
//        };
}

